<script setup lang="ts">
import FFmpegDemo from './components/FFmpegDemo.vue'
</script>

<template>
  <main>
    <FFmpegDemo />
  </main>
</template>
