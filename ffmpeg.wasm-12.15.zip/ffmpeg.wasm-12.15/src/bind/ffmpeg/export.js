const EXPORTED_FUNCTIONS = ["_ffmpeg", "_abort", "_malloc", "_ffprobe"];

console.log(EXPORTED_FUNCTIONS.join(","));
