const EXPORTED_RUNTIME_METHODS = [
  "FS",
  "setValue",
  "getValue",
  "UTF8ToString",
  "lengthBytesUTF8",
  "stringToUTF8",
];

console.log(EXPORTED_RUNTIME_METHODS.join(","));
